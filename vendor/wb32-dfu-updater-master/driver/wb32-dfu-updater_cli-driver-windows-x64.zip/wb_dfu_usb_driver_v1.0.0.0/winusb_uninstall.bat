@echo off
if "%PROCESSOR_ARCHITECTURE%"=="x86" goto X86
dpinst_amd64.exe /u wb_device_in_dfu_mode.inf
goto END
:X86
dpinst_x86.exe /u wb_device_in_dfu_mode.inf
:END
